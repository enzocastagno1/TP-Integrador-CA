#!/bin/bash

# Validacion de  argumentos
if [[ "$1" == "-help" || "$#" -ne 2 ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Verifica que el origen y destino existan
if [[ ! -d "$ORIGEN" ]]; then
    echo "ERROR: Directorio de origen no existe: $ORIGEN"
    exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "ERROR: Directorio de destino no existe: $DESTINO"
    exit 3
fi

# Nombre del archivo con fecha en formato YYYYMMDD
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

# Ejecuta el backup
tar -czf "${DESTINO}/${NOMBRE}" "$ORIGEN"
echo "Backup generado: ${DESTINO}/${NOMBRE}"
